#include "player.hpp"
#include <cstdlib>

namespace checkers
{

    GameState Player::play(const GameState &pState,const Deadline &pDue)
    {
        std::vector<GameState> lNextStates;
        pState.findPossibleMoves(lNextStates);

        if (lNextStates.size() == 0) return GameState(pState, Move());
        if (lNextStates.size() == 1) return lNextStates[0];
        /*
         * Here you should write your clever algorithms to get the best next move, ie the best
         * next state. This skeleton returns a random move instead.
         */
         //int values_childs = 0; // the evaluation of each of the childs, we will move to the one with the highest

         //uint8_t next_player_id = (pState.getNextPlayer() == CELL_WHITE) ? CELL_RED : CELL_WHITE;

         //std::cerr << "NEXT PLAYER: " << next_player_id << std::endl;

         //int alpha = std::numeric_limits<int>::min();
         //int beta = std::numeric_limits<int>::max();
         //int max = std::numeric_limits<int>::min();
         //int best_state = 0;
         int searchDepth = std::numeric_limits<int>::max();
        //int wanted_id = 0;

         /*for (int iter=0;iter<lNextStates.size();iter++)  //Iterate over possible future states
         {
           if(pDue.now() > pDue-0.1){
            break;
          }
           //std::cerr << "CHILD of player "<< unsigned(pState.getNextPlayer()) << " has values: " << std::endl;
           values_childs = algorithm(lNextStates[iter], alpha, beta, next_player_id, searchDepth); // current depth of the childs is 1 (0 for the parent)
           if( values_childs > max){
             max = values_childs;
             wanted_id = iter;
           }
         }
         */
         return iDeepSearch(pState.getNextPlayer(), lNextStates, searchDepth, pDue); //send current player and all the
         // next states for this player

    }

    /*A state space/graph search strategy in which a depth-limited version of depth-first search is run repeatedly with
     * increasing depth limits until the goal is found.*/
    GameState Player::iDeepSearch(uint8_t myPlayer, std::vector<GameState> lNextStates,
                                               int searchDepth, const Deadline &pDue)
    {
        GameState bestState = lNextStates[0]; // In case of timeout by default the returned state will be the first one
        std::vector<int> scoresStates(lNextStates.size(), 0); // initialize the scores to 0
        try
        {
            // For each depth run the alfa-beta algorithm, and for each depth the lNextStates order is changed as well
            // as its scores
            for (int depth = 1; depth < searchDepth; depth++)
            {
                bestState = moveBasedOnDepth(myPlayer, lNextStates, scoresStates, depth, pDue, searchDepth);
            }
        }
        catch (std::exception e)
        {
            /* Exception returned from the function alpha-beta in order to provide an answer*/
        }

        return bestState;
    }

    GameState Player::moveBasedOnDepth(uint8_t myPlayer, std::vector<GameState> &lNextStates, std::vector<int> &scoresStates,
            int depth, const Deadline &pDue, int searchDepth)
    {
        // First of all the states need to be ordered based on previous scoresStates using quicksort (algorithm copied
        // from https://www.geeksforgeeks.org/quick-sort/)
        if (lNextStates.size() > 1) {
            int low = 0;
            int high = lNextStates.size();
            quickSort(lNextStates, scoresStates, low, high);
        }
        int alpha = std::numeric_limits<int>::min();
        int beta = std::numeric_limits<int>::max();

        if (myPlayer == CELL_WHITE)
        {
            GameState bestState; // objective is to maximize
            int v = std::numeric_limits<int>::min();
            int maxValue = std::numeric_limits<int>::min();

            for (int i=0; i<lNextStates.size(); i++){
                v = algorithm(lNextStates[i], alpha, beta, CELL_RED, depth, pDue, searchDepth);
                // TODO: Check it goes before or after alpha
                scoresStates[i] = v; // no need to return v as we did for A1,A2
                alpha = std::max(v, alpha);
                if(v > maxValue) // save the maximum heuristic child
                {
                    maxValue = v;
                    bestState = lNextStates[i];
                }
            }
            return bestState;

        }
        else { // Player B
            GameState bestState; // objective is to minimize
            int v = std::numeric_limits<int>::max();
            int maxValue = std::numeric_limits<int>::max();

            for (int i=0; i<lNextStates.size(); i++){
                v = algorithm(lNextStates[i], alpha, beta, CELL_WHITE, depth, pDue, searchDepth);
                beta = std::min(beta,v);
                if(v < maxValue) // save the minimum heuristic child for the minimizer
                {
                    maxValue = v;
                    bestState = lNextStates[i];
                }
            }
            return bestState;
        }
    }

    void Player::quickSort(std::vector<GameState> &lNextStates, std::vector<int> &scoresStates, int low, int high)
    {
        if (low < high)
        {
            /* pi is partitioning index, arr[pi] is now
               at right place */
            std::cerr << "BEFORE ";
            for (int i=0; i<scoresStates.size(); i++)
            {
                std::cerr << scoresStates[i] << " ";
            }
            std::cerr << std::endl;
            int pi = partition(lNextStates, scoresStates, low, high);

            quickSort(lNextStates, scoresStates, low, pi - 1);  // Before pi
            quickSort(lNextStates, scoresStates, pi + 1, high); // After pi
            std::cerr << "AFTER ";

            for (int i=0; i<scoresStates.size(); i++)
            {
                std::cerr << scoresStates[i] << " ";
            }
            std::cerr << std::endl;
        }
    }

    /* This function takes last element as pivot, places
       the pivot element at its correct position in sorted
        array, and places all smaller (smaller than pivot)
       to left of pivot and all greater elements to right
       of pivot */
    int Player::partition (std::vector<GameState> &lNextStates, std::vector<int> &scoresStates, int low, int high)
    {
        int pivot = scoresStates[high];
        int i = low-1; // Index of smaller element (will start with index 1 as the 0 is already the pivot)
        for (int j = low; j <= high- 1; j++)
        {
            // If current element is bigger than or
            // equal to pivot
            if (scoresStates[j] >= pivot)
            {
                i++;
                swap(&scoresStates[i], &scoresStates[j]);
                swap_state(&lNextStates[i], &lNextStates[j]);
            }
        }
        swap(&scoresStates[i + 1], &scoresStates[high]);
        swap_state(&lNextStates[i + 1], &lNextStates[high]);

        return (i + 1);

    }

    // A utility function to swap two elements
    void Player::swap(int* a, int* b)
    {
        int t = *a;
        *a = *b;
        *b = t;
    }

    // A utility function to swap two elements
    void Player::swap_state(GameState* a, GameState* b)
    {
        GameState t = *a;
        *a = *b;
        *b = t;
    }

    int Player::algorithm(const GameState &pState, int alpha,
                          int beta, int myPlayer, int depth, const Deadline &pDue, int &searchDepthAllowed)
    {
        // As in A1,A2, where a final node is reached or we cannot continue evaluate
        if(pState.isEOG() || (depth == 0 && !pState.getMove().isJump()))
        {
            return gamma_function(pState, myPlayer);
        }

        // If no time left
        if(pDue.now() <= pDue-0.1){
            throw std::exception();
        }
        // Finf if the state Im dealing with already exists in order to reduce the amount of computation

        /*std::string stateId;
        int actualScore = 0;
        stateData tmpSv(actualScore, depth, myPlayer, searchDepthAllowed);
        std::string stringId, stringMirrorId;
        if (depth > 2) // TODO: Check what to put
        {
            stringId = tmpSv.idString(pState); // convert the state to string format
            stringMirrorId = tmpSv.IdMirrorString(pState); // convert the mirror state to string format
            if(improvedState(stringId, depth, searchDepthAllowed))
            {
                return hash_table.at(stringId).score;
            }
            else if(improvedState(stringMirrorId, depth, searchDepthAllowed))
            {
                return hash_table.at(stringMirrorId).score;
            }
        }*/
        // If continue through here means the state it was not saved before
        std::vector<GameState> newStates;
        pState.findPossibleMoves(newStates);

        orderStates(newStates, myPlayer); //order new movements based on the evaluation function of them if they were
        // leaves
        if (myPlayer == CELL_WHITE)
        {
            int v = std::numeric_limits<int>::min();
            for (int i=0; i<newStates.size(); i++){
                v = std::max(v, algorithm(newStates[i], alpha, beta, CELL_RED, depth-1, pDue, searchDepthAllowed));
                alpha = std::max(v, alpha);

                if (alpha >= beta)
                {
                    return v;
                }
            }
            // TODO: DO BEFORE OR AFTER IF(ALPHA >= BETA)
            // Store states
            /*if(depth > 2) // TODO: Check what to put
            {
                addState(stringId, depth, v, myPlayer, searchDepthAllowed); // add state to the hash_map
                addState(stringMirrorId, depth, v, myPlayer, searchDepthAllowed); // add state to the hash_map
                GameState reverseState = pState.reversed(); // same but mirrored
                std::string currentIdRev = tmpSv.idString(reverseState); // to be used by the enemy
                std::string currentIdRevMir = tmpSv.IdMirrorString(reverseState);
                addState(currentIdRev, depth, v, CELL_RED, searchDepthAllowed);
                addState(currentIdRevMir, depth, v, CELL_RED, searchDepthAllowed);
            }*/
            return v;
        }
        else { // Player B
            int v = std::numeric_limits<int>::max();
            for (int i=0; i<newStates.size(); i++){
                v = std::min(v, algorithm(newStates[i], alpha, beta, CELL_WHITE, depth-1, pDue, searchDepthAllowed));
                beta = std::min(beta,v);
                if (alpha >= beta)
                {
                    return v;
                }
            }
            // TODO: DO BEFORE OR AFTER IF(ALPHA >= BETA)
            // Store states
            /*if(depth > 2) // TODO: Check what to put
            {
                addState(stringId, depth, v, myPlayer, searchDepthAllowed); // add state to the hash_map
                addState(stringMirrorId, depth, v, myPlayer, searchDepthAllowed); // add state to the hash_map
                GameState reverseState = pState.reversed(); // same but mirrored
                std::string currentIdRev = tmpSv.idString(reverseState); // to be used by the enemy
                std::string currentIdRevMir = tmpSv.IdMirrorString(reverseState);
                addState(currentIdRev, depth, v, CELL_WHITE, searchDepthAllowed);
                addState(currentIdRevMir, depth, v, CELL_WHITE, searchDepthAllowed);
            }*/
            return v;
        }


    }
    /*Check if there is the same state but that has more levels of depth remaining to improve*/
    bool Player::improvedState(std::string stringId, int depth, int maxDepth)
    {
        try
        {
            // Check if a better state exists
            stateData state_data = hash_table.at(stringId);
            if((state_data.maxDepth - state_data.depth) >= (maxDepth - depth))
                return true;
            return false;
        }
        catch(std::out_of_range exception)
        {
            // What the hashMap returns if it does not exist the key
            return false;
        }
    }

    void Player::orderStates(std::vector<GameState> &states, int myPlayer)
    {
        if (states.size() > 1)
        {
            std::vector<int> scoresStates(states.size());
            for (unsigned int i = 0; i < states.size(); i++)
                scoresStates[i] = gamma_function(states[i], myPlayer);
            int low = 0;
            int high = states.size() - 1;
            quickSort(states, scoresStates, low, high);
        }
    }

    /*The evaluate function*/
    int Player::gamma_function(const GameState &pState, uint8_t player)
    {
        if (pState.isRedWin()) // the minimizer wins
        {
            return std::numeric_limits<int>::min();
        }
        else if (pState.isWhiteWin()) // The maximizer wins
        {
            return std::numeric_limits<int>::max();
        }
        else if (pState.isDraw())
        {
            return 0; // As draw doesnt work to pass the assigment we could give negative value as well
        }
        else
        {
            int pieces_white = 0;
            int pieces_red = 0;
            std::vector<int> pieces(4); //1st: Kings white, 2nd: Kings red, 3rd: White pieces, 4th: Red pieces


            // Check number of kings
            for (int i=0; i<32; i++) {
                uint8_t check = pState.at(i);
                if (check == CELL_RED) {
                    if (check == CELL_KING) // king red cell
                    {
                        pieces_red += 5 * heuristicRed[i]; // the heuristic of red is the bigger the row the better
                    } else {
                        pieces_red += heuristicRed[i];
                    }
                } else if (check == CELL_WHITE)
                {
                    if (check == CELL_KING) // king red cell
                    {
                        pieces_white += 5 * heuristicWhite[i]; // the heuristic of red is the bigger the row the better
                    } else {
                        pieces_white += heuristicWhite[i];
                    }
                }

            }
            // return the difference between the red ones and the white ones
            return (pieces_red-pieces_white);
        }

    }

    void Player::addState(const std::string stringId, const int depth,
                                       const int score, const int player, int maxdepth)
    {
        try
        {
            /*
              If there is a state stored with the same id but we can explore deeper, we
              replace the state.
            */
            stateData sv = hash_table.at(stringId);
            if((sv.maxDepth - sv.depth) < (maxdepth - depth))
            {
                sv.depth = depth;
                sv.maxDepth = maxdepth;
                sv.score = score;
                sv.myPlayer = player;
            }
        }
        catch(std::out_of_range exception)
        {
            // If the state hasn't been repeated before, store it
            stateData sv(score, depth, player, maxdepth);
            hash_table.insert({stringId, sv});
        }
    }



/*namespace checkers*/ }
